<template>
    <sw-page class="clb-badge-detail" :showSearchBar="false" :showSmartBar="false">
        <template #content>
            <sw-data-grid
                :dataSource="products"
                :columns="columns"
                :show-selection="true"
                full-page
                :is-loading="isLoading"
            >
                <template #actions="{ item }">
                    <sw-context-menu-item
                        class="sw-product-list-grid__duplicate-action">
                        listing.actionUploa
                    </sw-context-menu-item>
                </template>

                <template #column-stock="{ item }">
                    {{ item.stock }}
                </template>

                <template #pagination>
                    <sw-pagination
                        :page="page"
                        :limit="limit"
                        :total="total"
                        @page-change="onPageChange"
                    />
                </template>

            </sw-data-grid>
            <sw-loader v-if="isLoading" />
        </template>

        <template #sidebar>
            <sw-sidebar>
                <sw-sidebar-item
                    icon="default-arrow-360-left"
                    title="Duc Le"
                    @click="getList"
                />
            </sw-sidebar>
        </template>

    </sw-page>
</template>

<script>

export default {
    data: () => ({
        products: [],
        isLoading: false,
        total: 0,
        page: 1,
        limit: 25,
    }),

    computed: {
        columns() {
            return [{
                property: 'name',
                label: this.$tc('listing.name'),
                inlineEdit: 'string',
                allowResize: true,
                primary: true,
            }, {
                property: 'email',
                naturalSorting: true,
                label: this.$tc('listing.email'),
                align: 'right',
                allowResize: true,
            }];
        },
    },

    created() {
        this.createdComponent();
    },

    methods: {
        createdComponent() {
            window.parent.postMessage('sw-app-loaded', '*')
            this.getList();
        },

        async getList() {
            const params = {
                page: this.page,
                limit: this.limit,
                ...this.$route.query
            };

            this.isLoading = true;
            const url = 'http://boostday.test/api/users';
            const response = await this.axios.get(url, {params: params});

            this.products = response.data.data;
            this.total = response.data.total;
            this.page = response.data.current_page;

            this.isLoading = false;
        },

        onPageChange({page = 1, limit = 25}) {
            this.page = page;
            this.limit = limit;

            this.getList();
        },
    }
}
</script>

<style scoped>

</style>
