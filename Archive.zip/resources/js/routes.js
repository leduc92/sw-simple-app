import users from './components/users.vue';
export const routes = [
    {
        name: 'users',
        path: '/',
        component: users
    }
];
